#!/bin/sh
#  this script will be called by the userdata to mount /db filesystem.
#  Always call this script even the ebs /db is not available yet.
if [ $# -ne 2 ] ; then
   echo "$0 devicename mountpoint"
   exit 1
fi
DEVNAME=`echo $1 | sed "s:/dev/::" `
MOUNTP=$2
TMPFILE=/tmp/uuid.txt.$$
echo "Checking if there is block device $DEVNAME ..."
cnt=`lsblk | grep -c $DEVNAME`
if [ $cnt -ne 1 ] ; then
   echo "DEVICE $DEVNAME does NOT exist"
   exit 1
fi

echo "Checking if the $DEVNAME has been initialized ..."
cnt=`file -s /dev/$DEVNAME | grep -c ': data'`
if [ $cnt -ne 1 ] ; then
   echo "DEVICE $DEVNAME is already INITIALIZED."
else
   echo "Initializing device $DEVNAME ..."
   mkfs -t ext4 /dev/$DEVNAME
fi

echo "Creating mounting point $MOUNTP..."
mkdir -p $MOUNTP
chown oracle:dba $MOUNTP

blkid /dev/$DEVNAME | awk '{print $2 " MOUNTP ext4 defaults,nofail  0 2"}' | sed s/\"//g > $TMPFILE

echo "Updating the /etc/fstab ..."
cp -p /etc/fstab /etc/fstab.backup.$$
sed "s:MOUNTP:$MOUNTP:g" $TMPFILE >> /etc/fstab
chown oracle:dba $MOUNTP

/bin/rm $TMPFILE 
